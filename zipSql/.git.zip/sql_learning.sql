create database sql_learning;
use sql_learning;

drop table students ;
create table students(
	student_id int primary key auto_increment,
    name varchar(50),
    age int ,
    gender varchar(30),
    department varchar(40),
    city varchar(59),
    marks int,
    attendance decimal(5,2),
    course varchar(40),
    admission_year int );
    
select*from students;

select distinct course from students;
select course from students group by course;

select name from students where name like 'a%';

select course , count(*) from students group by course  ;
select max(marks) as highest_mark from students;

select max(marks) from students where marks <(select max(marks) from students) ;

select substring(name,1,2) from students;

select instr(lower(name),'a') from students where name='manoj';

select distinct name,length(name) from students;

INSERT INTO students
(name, age, gender, department, city, marks, attendance, course, admission_year)
VALUES
('Arun', 20, 'Male', 'CSE', 'Salem', 85, 92.50, 'Java', 2024),
('Bala', 21, 'Male', 'ECE', 'Chennai', 72, 88.00, 'Python', 2023),
('Divya', 20, 'Female', 'CSE', 'Madurai', 95, 96.50, 'Python', 2024),
('Kavi', 22, 'Female', 'IT', 'Coimbatore', 68, 79.50, 'SQL', 2022),
('Manoj', 21, 'Male', 'CSE', 'Theni', 78, 85.00, 'Java', 2023),
('Priya', 20, 'Female', 'ECE', 'Salem', 91, 94.00, 'Python', 2024),
('Rahul', 23, 'Male', 'IT', 'Chennai', 55, 70.00, 'SQL', 2022),
('Sneha', 21, 'Female', 'CSE', 'Coimbatore', 88, 90.50, 'Java', 2023),
('Vijay', 22, 'Male', 'MECH', 'Madurai', 64, 76.00, 'Python', 2022),
('Anu', 20, 'Female', 'CSE', 'Theni', 97, 98.00, 'SQL', 2024),
('Dinesh', 21, 'Male', 'IT', 'Salem', 81, 89.00, 'Java', 2023),
('Keerthi', 22, 'Female', 'ECE', 'Coimbatore', 74, 82.50, 'SQL', 2022),
('Sathish', 23, 'Male', 'CSE', 'Chennai', 69, 75.00, 'Python', 2022),
('Nandhini', 20, 'Female', 'IT', 'Madurai', 93, 95.00, 'Java', 2024),
('Surya', 21, 'Male', 'CSE', 'Salem', 87, 91.00, 'SQL', 2023);


-- Level 1 — SELECT
select*from students;


select name ,marks from students;

select name,department,city from students;

-- Level 2 — WHERE
select *from students where marks>80;

select name,course,department from students where marks>90;
select name,course,department,marks from students where marks>90 ;
select count(*) from students ;

select name,marks from students order by marks desc;

select city from students group by city ;

select*FROM  students where marks between 50 and 100;
select *from students where department in ("cse","it");

	-- Level 3 — AND / OR / NOT-- 
    
select * from students where department ='cse' and marks >60;
select *from students where city ='salem' or city='chennai' ;

select*from students where not department ='cse';


-- Level 4 — ORDER BY

select*from students order by marks;
select*from students order by marks desc;

select name,marks from students order by marks;

-- Level 5 — LIMIT
select*from students limit 5;
select*from students order by marks desc limit 4;

   --  Level 6 — DISTINCT
select distinct department from students;
select distinct city from students ;
select distinct course from students;

 --  Level 7 — Aggregate Functions
-- -- COUNT()
-- SUM ()
-- AVG()
-- MIN()
-- MAX()

select count(*) from students;
select avg(marks) from students;
select max(marks) from students;
select min(marks) from students;
select sum(marks) from students;


    -- Level 8 — GROUP BY 
    
select department , count(*) from students group by department;
select department ,avg(marks) from students group by  department ;
select city ,max(marks) from students group by city;

		-- Level 9 — HAVING

select department , avg(marks) from students group by department having avg(marks)>74;
    
 -- WHERE → filters rows
-- HAVING → filters groups

-- Level 10 — UPDATE-- 

update students set marks=99 where student_id =1;
select *from students where student_id =1;

-- Level 11 — DELETE

delete from students where student_id =15;

-- Level 12 — ALTER TABLE-- 

alter table students add email varchar(39);
-- Modify:-- 
alter table students modify email varchar(100);
-- Drop:
alter table students drop column email;

-- 13. Create a Second Table — For JOIN Practice

create table courses(
course_id int primary key,
course_name varchar(40),
duration_month int,
fee int
);

insert into courses values
(1,'java',6,15000),
(2,'python',5,12000),
(3,'Sql',4,10000);

select*from courses;

select*from students join courses on students.course=courses.course_name;

select 
	students.name,
    students.course,
    courses.duration_month,
    courses.fee
from students
join courses
on students.course = courses.course_name;


select 
	students.name,
    students.department,
    students.city,
    courses.course_id,
    courses.fee
from students 
join courses
on students.course = courses.course_name;

-- 1. Basic LEFT JOIN
select 
	students.name,
    students.department,
    students.course,
    courses.course_id,
    courses.fee
from students
left join courses 
on students.course = courses.course_name;


-- 3. Practice
-- Question 1: Display all students and their course fees.

select 
	students.name,
    students.course,
    courses.fee
from students
left join courses
on students.course=courses.course_name;


-- Question 2: Display only CSE students with their course fee-- 

select 
	students.name,
    students.department,
    students.course,
    courses.fee
from students 
left join courses
on students.course = courses.course_name
where students.department="cse";

-- Question 3: Display students whose course fee is greater than ₹12,000.

select 
	students.name,
    students.course,
    courses.fee
from students
left join courses 
on students.course = courses.course_name 
where courses.fee>12000;

    --   1. Basic RIGHT JOIN
    
select
	students.name,
    students.department,
    students.course,
    courses.course_id,
    courses.fee
from students 
right join courses
on students.course= courses.course_name;


-- 3. Practice
-- Question 1:
-- Display all courses and the students studying them.


select 
	courses.course_id,
    courses.course_name,
    courses.fee,
    students.name
from students
right join courses 
on students.course = courses.course_name;



select
	students.name,
    students.gender,
    students.course,
    courses.fee,
    courses.course_name
from students
join courses
on students.course= courses.course_name;
    
    
    -- Question 2:-- 
-- Display all courses and student names, sorted by fee.

select
	courses.course_name,
    courses.fee,
    students.name
from students 
right join courses 
on students.course = courses.course_name
order by courses.fee desc;


-- ⚠️ MySQL does not directly support FULL OUTER JOIN. You can simulate it using LEFT JOIN, RIGHT JOIN, and UNION.

select 
	students.name,
    students.department,
    students.course,
    courses.course_id,
    courses.fee
from students 
left join courses
	on students.course= courses.course_name
union

select
	students.name,
    students.department,
    students.course,
    courses.course_id,
    courses.fee
from students
right join courses
	on students.course = courses.course_name;
    
    
    
		-- 1. Subqueries

select name,marks from students where marks>(select avg(marks) from students);
	

-- 2. CASE Statement

select name,marks, 
case 
	when marks >= 90 then "excelent"
    when marks >= 60 then "GOOD"
    when marks >= 40 then "AVERAGE"
    else 'POOR'
end as grade 
from students;
		
-- 3. GROUP BY + HAVING

select department ,avg(marks) as average_marks
from students 
group by department
having avg(marks)>75;






-- 4. String Functions-- 

select 
	upper(name) as uppercase_name,
    lower(city) as lowercase_city,
    length(name) as name_length
from students;


-- 5. Date Functions

select
	curdate() as today,
    now() as current_timing;
    
    
-- 6. union 

select name as person 
from students 
where city ='salem'
union 
select name as person 
from students
where city='chennai';



-- 7. Common Table Expressions (CTEs)

with high_scorers as (select
name,marks from students 
where marks>=85)
select * 
from high_scorers;



-- windows function 


select name,department,marks,rank() over (partition by department order by marks desc )
as department_rank from students;


-- 9. view

create view top_students as select name,department,marks from students where marks>=85;
select*from students;



CREATE VIEW top_students AS
SELECT name, department, marks
FROM students
WHERE marks >= 85;

-- SQL Medium Concept 11: COALESCE()
-- Concept: Replace NULL with another value.alter

select
	name,
    coalesce(city, 'unknown') as city from students;

select 
	name,
	coalesce(coures,'not assigned' ) as course from students;


-- S QL Medium Concept 12: IFNULL()
-- Concept: Replace a NULL value with another value in MySQL.


select
	name,
    ifnull(city,'unknown') as city from students;
    
select
	name,
	ifnull(course, 'not assigned' ) as course from students;




-- Replace NULL with another values 
select 
   name,coalesce(city,'unknown ') as city from students;

select 
    name, coalesce (course,'Not Assigned') as course from students;



    
    
