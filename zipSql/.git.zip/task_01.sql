create DATABASE college_db;

Use college_db;

create table student(
	student_id int primary key,
    Name_ varchar(50),
    age int,
    departament varchar(50),
    marks int (50),
    city varchar(50)
    );

select*from student where name='name' and departament='departament';

insert into student values
(1,'sam',34,'cse',56,'chennai'),
(2,'aruv',34,'bce',56,'dubai');

insert into student values
(3,'rahul',45,'it',43,'salem'),
(4,'jay',56,'mech',56,'goa');

insert into student values
(5,'naser',56,'pct',54,'singapor'),
(6,'alli',34,'tt',32,'germany');

insert into student values
(8,'basha',43,'cse',70,'kochi');

select distinct departament from student;

select name as stdudent_name from student;

select*from student where departament='cse' and departament='ece';

select*from student where departament='cse' or departament='ece';


create table stuff(





select*from student;
select*from student order by name asc;
select count(*) as total_students from student;
select departament,count(*) as total_students from student group by departament;
select departament,avg(marks) as average_marks from student group by departament;

select departament,avg(marks) as average_marks from student group by departament having avg(marks)>60;

select * from student where marks between 50 and 70;


update student set marks =90 where student_id = 5;

update student set city='thai' where student_id = 3;

alter table student add email varchar(100);
update student set email='dhana@gmail.com' where student_id=3;

update student set email = 'jhon@gmail.com' where student_id =4;




select*from student where name like 's%';
select*from student where name like '%n';

select *from student where departament='cse' and marks >50;

select *from student where city in ('chennai','goa');

select *from student order by marks asc limit 5;

update student set marks=98 where student_id =1;

update student set city='the nilgiris' where student_id=1;









select*from student where marks>50;
select *from student where departament='cse';

select name, marks from student;

select*from student where marks>40;

select*from student order by marks desc;

select max(marks) as highest_marks from student;

select min(marks) as highest_marks from student;

select avg(marks) as highest_marks from student;

select name from student;


select *from student;
select*from student where marks;
select marks from student;

select
marks , (marks+10)
from student;

drop table stuffs;
create table stuffs(
	stuffs_id int primary key,
    Name_ varchar(50),
    age int,
    departament varchar(50),
    grade int,
    city varchar(50)
    );
    
insert into stuffs values( 1,'suganthini',35,'cse',1,'erode' );
insert into stuffs values( 2,'divya deepa',25,'cse',4,'ooo' );
insert into stuffs values( 3,'baby',38,'cse',6,'buvani' );
insert into stuffs values( 4,'sasi',35,'cse',1,'erode' );
insert into stuffs values( 5,' deepa',25,'cse',4,'rr' );
insert into stuffs values( 6,'saii',38,'cse',6,']ch' );

select*from stuffs;
select*from student;

create table student(
	student_id int primary key,
    Name_ varchar(50),
    age int,
    departament varchar(50),
    marks int (50),
    city varchar(50)
    );
    
with rk as (select student_id,age,departament,marks,city, row_number () over (partition by age order by marks asc) as alll from student)
select student_id,age,marks from student where alll =3;


select s.student_id,o.stuffs_id  from student s join  stuffs o on s.student_id = o.stuffs_id;
select s.student_id,o.stuffs_id  from student s left join  stuffs o on s.student_id = o.stuffs_id;
-- 3;58;
select s.student_id,o.stuffs_id  from student s right join  stuffs o on s.student_id = o.stuffs_id;


select departament,marks, sum(marks) over (partition by departament ) as total from student;

select grade , name_,age, sum(grade) over (partition by name_ order by age asc) as names_ from stuffs;

select name,city,age , row_number() over( partition by age order by age asc ) as order_ from student; 





    